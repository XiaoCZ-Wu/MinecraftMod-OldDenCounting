import json
cards = { "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, #"zero": 0,
    "seven": 7,"eight": 8, "nine": 9, "mol": 10}
list_k = list(cards.keys())
list_v = list(cards.values())
for v1 in list_v:
    for v2 in list_v:
        if v1 % v2 == 0 and v1 != 1 and v2 != 1:
            new = {
                "type": "minecraft:stonecutting",
                "ingredient": {"item": "odcounting:" + list_k[list_v.index(v1)]},
                "result": "odcounting:" + list_k[list_v.index(int(v1 / v2))],
                "count": v2
            }
            with open(
                "division/d_" + str(v1) + "_" + str(v2) + ".json", "w", encoding="utf-8"
                ) as file:
                json.dump(new, file, indent=4, ensure_ascii=False)