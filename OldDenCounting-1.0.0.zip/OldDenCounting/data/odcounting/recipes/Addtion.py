import json
cards = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
    "seven": 7,"eight": 8, "nine": 9, "mol": 10}
list_k = list(cards.keys())
list_v = list(cards.values())
for v1 in range(0, 11):
    for v2 in range(0, 11):
        new = {
            "type": "minecraft:crafting_shapeless",
            "ingredients": [
                {"item": "odcounting:" + list_k[list_v.index(v1)]},
                {"item": "odcounting:" + list_k[list_v.index(v2)]}
            ],
            "result": {
                "item": "odcounting:",
                "count": 1
                }
        }
        if v1 + v2 <= 10:
            new["result"]["item"] += list_k[list_v.index(v1 + v2)]
        else:
            for v3 in range(10, 0, -1):
                if (v1 + v2) % v3 == 0:
                    new["result"]["item"] += list_k[list_v.index(v3)]
                    new["result"]["count"] = int((v1 + v2) / v3)
                    break
        with open(
            "addtion/a_" + str(v1) + "_" + str(v2) + ".json", "w", encoding="utf-8"
            ) as file:
            json.dump(new, file, indent=4, ensure_ascii=False)